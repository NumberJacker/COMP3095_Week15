INSERT INTO t_inventory (quantity, sku_code)
VALUES ( 100, 'SKU001'),
       ( 200, 'SKU002'),
       ( 300, 'SKU003'),
       ( 400, 'SKU004'),
       ( 500, 'SKU005');
