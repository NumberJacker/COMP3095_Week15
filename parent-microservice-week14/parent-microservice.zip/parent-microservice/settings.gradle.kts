rootProject.name = "parent-microservice"

include("product-service", "order-service", "inventory-service", "api-gateway", "notification-service")
